Useage:
HyperScienceUploader.exe upload 
-f the file name of the file to be uploaded 
-e th external id
-m the metadata

Example
HyperScienceUploader.exe upload -f ITSA25963080.jpg -e TESTID000106 -m "{\"matchingInput\": {\"patientName\": {\"values\": [\"Test Name\"],\"fuzzyMatching\": true,\"reverseMatching\": true,\"ignoreChars\": true,\"isDate\": false},\"treatmentDate\": {\"values\": [\"21/10/2010\"],\"fuzzyMatching\": false,\"reverseMatching\": false,\"ignoreChars\": false,\"isDate\": true},\"treatmentType\": {\"values\": [\"Consultation\",\"Visit\",\"Test\"],\"fuzzyMatching\": true,\"reverseMatching\": false,\"ignoreChars\": false,\"isDate\": false},\"amount\": {\"values\": [43.56],\"fuzzyMatching\": false,\"reverseMatching\": false,\"ignoreChars\": false,\"isDate\": false}}}"